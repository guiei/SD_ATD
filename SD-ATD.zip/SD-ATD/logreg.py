import torch
import torch.nn as nn
import torch.nn.functional as F
from colorama import Fore
from tqdm import tqdm
from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score
class LogReg(nn.Module):
    def __init__(self, ft_in, nb_classes):
        super(LogReg, self).__init__()
        self.fc = nn.Linear(ft_in, nb_classes)
        for m in self.modules():
            self.weights_init(m)

    def weights_init(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight.data)
            if m.bias is not None:
                m.bias.data.fill_(0.0)

    def forward(self, seq):
        ret = self.fc(seq)
        return ret

def mytest(feature,data,model):
    # model.eval()
    # z = model.encoder(data.x, data.edge_index)
    z  = model.outEmb(data.x, data.full_adj_t)
    # z = embedding
    embs = z
    lable = data.y
    nb_classes = int(lable.max() - lable.min()) + 1
    lable = lable.to("cuda:0")
    train_lbls = lable[data.train_mask]
    test_lbls = lable[data.test_mask]
    embs = embs / embs.norm(dim=1)[:, None]
    train_embs = embs[data.train_mask]
    test_embs = embs[data.test_mask]
    accs = []
    accs_small = []
    nmis = []  # 添加NMI列表
    aris = []  # 添加ARI列表
    xent = nn.CrossEntropyLoss()
    for _ in range(5):
        log = LogReg(z.shape[1], nb_classes)
        opt = torch.optim.Adam(log.parameters(), lr=0.01, weight_decay=0.005)
        log.to("cuda:0")

        for _ in range(100):
            log.train()
            opt.zero_grad()
            logits = log(train_embs)
            loss = xent(logits, train_lbls)
            loss.backward(retain_graph=True)
            opt.step()

        logits = log(test_embs)
        preds = torch.argmax(logits, dim=1)

        # 计算准确率
        acc = torch.sum(preds == test_lbls).float() / test_lbls.shape[0]
        accs.append(acc * 100)

        # 计算NMI和ARI
        nmi = normalized_mutual_info_score(test_lbls.cpu().numpy(), preds.cpu().numpy())
        ari = adjusted_rand_score(test_lbls.cpu().numpy(), preds.cpu().numpy())
        nmis.append(nmi * 100)
        aris.append(ari * 100)

        # 计算每个类别的准确率
        ac = []
        for i in range(nb_classes):
            acc_small = torch.sum(preds[test_lbls == i] == test_lbls[test_lbls == i]).float() / \
                        test_lbls[test_lbls == i].shape[0]
            ac.append(acc_small * 100)
        accs_small = ac

    # 计算平均值和标准差
    accs = torch.stack(accs)
    nmis = torch.tensor(nmis)
    aris = torch.tensor(aris)

    # 打印结果
    string_3 = ""
    for i in range(nb_classes):
        string_3 = string_3 + "|{:.1f}".format(accs_small[i].item())

    string_2 = Fore.GREEN + " ACC: {:.1f}±{:.2f}, NMI: {:.1f}±{:.2f}, ARI: {:.1f}±{:.2f} ".format(

        accs.mean().item(), accs.std().item(),
        nmis.mean().item(), nmis.std().item(),
        aris.mean().item(), aris.std().item()
    )

    tqdm.write(string_2 + string_3)
    # noe = t()

    print('Acc, nmi:', acc, nmi)